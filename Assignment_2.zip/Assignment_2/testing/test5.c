
int h()

int main(){
    int a
    int b
    int c;
    int a= sizeof(int ;
    if("ehlloo"){};
    int a[][][;

}
int g
int ggg;