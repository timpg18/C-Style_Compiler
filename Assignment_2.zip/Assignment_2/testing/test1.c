int f(int a, char* s, bool g){
    return 5;
}

int add(int a, int b){
    return add(a - 1, b + 1);
}


int main(){

}

int main(){
    for(int i=0;i<100;i++){
        int x;
    }
    int y;
    do{
        y++;
    } while(y < 10);

    do{
        y--;
    } until(y <0);

    int g = malloc(5);
    int (*ptr)(int,int);
    
    

}