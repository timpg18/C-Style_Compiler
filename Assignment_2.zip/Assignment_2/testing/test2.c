
struct hello{
    int x;
    int y;
};
enum MyEnum {
    Y,  // implicitly 0
    Z   // implicitly 1
};

enum Day {
    Monday,
    Tuesday, 
    Wednesday} z;

    

int f(int& a){
    return 1;
}

class Hello{
    public:{
        int x;
        int y;
    }
    private:{
        int z;
    }
    private:{
        int gg;
    }
} W;

struct{
    int x;
    int y;
} A;

int main(){
// typedef int myint;
class Hello y;
enum Day g = Monday;
struct hello y;
}
