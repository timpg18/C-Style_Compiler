typedef int myint;


int main(){
    myint x,y,z;
    int arr[1000][1000];
    const int**** p;
    int***  z;
    static int zz = 12;
    auto auto auto auto ee = 12;
    int a = (b+d)*(e/g);
    if(c == 5){
        a = 1;
    }
    else a = 2;
    while(a < 0){
        a++;
    }
    switch(Z){
        case 12:
        Z = 5;
        break;
        case 15:
        Z = 12;
        break;
    }
    int ar[4];
    char* www;
    int ***w;
    bool y = true;
    printf("hehe");
    scanf("ww");

    
}