int main(){
    '\0'
    '\n'
    '\\n'
    '\\b'
    '
    'hello'
    "hello;
    hello"
    "hello"
    '\t\n'
    /* 
    adsadmalkdams dandalkd ca
    */
    /*
    int x = 5;

}